import express from 'express';
import multer from 'multer';
import { fal } from '@fal-ai/client';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024 } });
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(__dirname));

if (process.env.FAL_KEY) fal.config({ credentials: process.env.FAL_KEY });


app.post('/api/generate', upload.single('image'), async (req, res) => {
  try {
    if (!process.env.FAL_KEY) return res.status(503).json({ error: 'Server owner must set FAL_KEY in .env first.' });
    const prompt = String(req.body.prompt || '').trim();
    const mode = req.body.mode === 'image' ? 'image' : 'text';
    if (!prompt) return res.status(400).json({ error: 'Enter a prompt.' });
    const seconds = Number(req.body.seconds || 5);
    const aspectRaw = req.body.aspect || '9:16';
    const aspect = aspectRaw.startsWith('16:9') ? '16:9' : aspectRaw.startsWith('1:1') ? '1:1' : '9:16';
    const style = req.body.style || 'Cinematic';
    const finalPrompt = `${prompt}. Visual style: ${style}.`;
    const common = { prompt: finalPrompt, duration: seconds, prompt_expansion_mode: 'disabled', enable_safety_checker: true };
    let endpoint, input;
    if (mode === 'image') {
      if (!req.file) return res.status(400).json({ error: 'Upload an image for image-to-video.' });
      const blob = new Blob([req.file.buffer], { type: req.file.mimetype });
      const imageUrl = await fal.storage.upload(blob);
      endpoint = 'fal-ai/minimax/h3-max-turbo/image-to-video';
      input = { ...common, image_url: imageUrl };
    } else {
      endpoint = 'fal-ai/minimax/h3-max-turbo/text-to-video';
      input = { ...common, aspect_ratio: aspect };
    }
    const result = await fal.subscribe(endpoint, { input, logs: true, onQueueUpdate: (u) => console.log(u.status) });
    const videoUrl = result?.data?.video?.url || result?.video?.url || result?.video_url || result?.output?.video?.url;
    if (!videoUrl) return res.status(502).json({ error: 'Model returned no video URL. Check the provider model schema.' });
    res.json({ videoUrl, provider: 'fal.ai', endpoint });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || 'Generation failed. Please check your API/model configuration.' });
  }
});
app.get('/api/health', (_, res) => res.json({ ok: true, keyConfigured: Boolean(process.env.FAL_KEY) }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`VYRO AI Studio running on http://localhost:${port}`));
