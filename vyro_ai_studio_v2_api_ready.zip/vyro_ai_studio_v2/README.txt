VYRO AI STUDIO - API CONNECTED STARTER

This project includes Text-to-Video and Image-to-Video using fal.ai MiniMax H3 Max Turbo endpoints.

LOCAL SETUP (requires a computer with Node.js 20+)
1. Extract the ZIP.
2. Copy .env.example to .env and set FAL_KEY to your secret API key.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000

DEPLOYMENT (Render or another Node hosting provider)
1. Upload this project to a private GitHub repository. Do not commit .env or any API key.
2. Create a Node web service from that repo on your host.
3. Set build command: npm install
4. Set start command: npm start
5. Add environment variable FAL_KEY in the host's Environment/Secrets settings. Paste the key there, never in browser HTML or chat.
6. Deploy and open the hosted site.

MODEL DETAILS
Text endpoint: fal-ai/minimax/h3-max-turbo/text-to-video
Image endpoint: fal-ai/minimax/h3-max-turbo/image-to-video
The API schema and pricing can change; confirm on fal.ai before running paid requests.

SECURITY / COST
Keep FAL_KEY server-side only. Never share screenshots exposing the key. Generation consumes provider credits. This starter is not production-ready: add authentication, rate limits, spending limits, storage cleanup, and request validation before offering it publicly.
